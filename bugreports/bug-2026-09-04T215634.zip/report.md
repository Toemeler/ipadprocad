# Bug report — 2026-09-04T21:56:34.150151

- **captured**: 2026-09-04T21:56:34.340322
- **build**: ffca7b8
- **os**: ios Version 27.0 (Build 24A5424a)
- **dart**: 3.13.2 (stable) (Tue Aug 25 01:01:12 2026 -0700) on "ios_arm64"
- **locale**: de_CH
- **qcad backend**: REAL — Prototype C-API 0.1.0 (Qt 6.7.3)
- **occt backend**: Prototype OCCT shim v29 (OCCT 7.9.3) (shim v29)
- **open part**: whale_stl
- **parts loaded**: 1

## What the user saw

this is an imported file. but on the second opening ost of the parts is gone

## Triage

No broken feature, no non-finite geometry, no missing body. The model is internally healthy, so the fault is in the interaction or the display — read `log.txt` around the timestamp above rather than `state.txt`.

## Shape of the model

- part: `whale_stl`
- features: 1 (0 sick)
- sketches: 0
- work planes: 0

## Contents

- `part.json` — the document itself; load this to reproduce
- `state.txt` — every feature, its parameters, its solid or its error, every picked edge fingerprint, and every sketch with its full geometry and constraint list
- `log.txt` — this session (11167 lines); the report was written at the END of it
- `perf.txt` — frame and remesh timings
- `gestures.txt` — the RAW pointer stream leading into the report, before the gesture arena resolved it. Read this when the complaint is that a tap or drag did the wrong thing
- `reality.txt` — what Dart last handed the native renderer. The 3D body is drawn by RealityKit behind a platform view, so this is the last thing visible from this side of that boundary
- `screenshot.png` — what was on screen.
- `env.txt` — build, device and backend versions
