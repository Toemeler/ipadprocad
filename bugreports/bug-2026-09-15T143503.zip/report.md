# Bug report — 2026-09-15T14:35:03.320835

- **captured**: 2026-09-15T14:35:03.421124
- **build**: 98f27fa
- **os**: windows "Windows 10 Home" 10.0 (Build 19045)
- **dart**: 3.13.3 (stable) (Tue Sep 1 01:07:17 2026 -0700) on "windows_x64"
- **locale**: en_GB
- **qcad backend**: REAL — Prototype C-API 0.1.0 (Qt 6.8.3)
- **occt backend**: Prototype OCCT shim v29 (OCCT 7.9.3) (shim v29)
- **display**: 1x — 2560 x 1400 logical, 2560 x 1400 physical
- **text scale**: 1.0
- **glass**: shader filter, program loaded
- **open part**: Part1
- **parts loaded**: 1

## What the user saw

i get this really weird white artifacts on the modell browser

## Triage

No broken feature, no non-finite geometry, no missing body. The model is internally healthy, so the fault is in the interaction or the display — read `log.txt` around the timestamp above rather than `state.txt`.

## Shape of the model

- part: `Part1`
- features: 0 (0 sick)
- sketches: 1
- work planes: 0

## Contents

- `part.json` — the document itself; load this to reproduce
- `sketches/` — 1 child sketch document(s)
- `state.txt` — every feature, its parameters, its solid or its error, every picked edge fingerprint, and every sketch with its full geometry and constraint list
- `log.txt` — this session (24162 lines); the report was written at the END of it
- `perf.txt` — frame and remesh timings
- `gestures.txt` — the RAW pointer stream leading into the report, before the gesture arena resolved it. Read this when the complaint is that a tap or drag did the wrong thing
- `reality.txt` — what Dart last handed the renderer. The shaded body is drawn by flutter_scene INSIDE Flutter here, so it is in `screenshot.png` too; this is the scene it was drawn from
- `screenshot.png` — what was on screen.
- `env.txt` — build, device and backend versions
