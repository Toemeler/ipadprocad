# Bug report — 2026-09-16T15:29:37.894174

- **captured**: 2026-09-16T15:29:37.950228
- **build**: 4245449
- **os**: windows "Windows 10 Home" 10.0 (Build 19045)
- **dart**: 3.13.3 (stable) (Tue Sep 1 01:07:17 2026 -0700) on "windows_x64"
- **locale**: en_GB
- **qcad backend**: REAL — Prototype C-API 0.1.0 (Qt 6.8.3)
- **occt backend**: Prototype OCCT shim v29 (OCCT 7.9.3) (shim v29)
- **display**: 1x — 1376 x 1032 logical, 1376 x 1032 physical
- **text scale**: 1.0
- **glass**: shader filter, program loaded
- **open part**: (none)
- **parts loaded**: 2

## What the user saw

the preview images in windows are still not made with flutter gpu 3d renderer

## Triage

- no part is open

## Contents

- `log.txt` — this session (19299 lines); the report was written at the END of it
- `perf.txt` — frame and remesh timings
- `gestures.txt` — the RAW pointer stream leading into the report, before the gesture arena resolved it. Read this when the complaint is that a tap or drag did the wrong thing
- `reality.txt` — what Dart last handed the renderer. The shaded body is drawn by flutter_scene INSIDE Flutter here, so it is in `screenshot.png` too; this is the scene it was drawn from
- `screenshot.png` — what was on screen.
- `env.txt` — build, device and backend versions
