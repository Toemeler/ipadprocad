# Bug report — 2026-08-28T21:44:56.453182

- **captured**: 2026-08-28T21:44:56.622115
- **build**: dd6e2ee
- **os**: ios Version 27.0 (Build 24A5390f)
- **dart**: 3.13.2 (stable) (Tue Aug 25 01:01:12 2026 -0700) on "ios_arm64"
- **locale**: de_CH
- **qcad backend**: REAL — Prototype C-API 0.1.0 (Qt 6.7.3)
- **occt backend**: Prototype OCCT shim v29 (OCCT 7.9.3) (shim v29)
- **open part**: Lesezeichen_Schmetterling 2
- **parts loaded**: 2

## What the user saw

the dropdowns color and rendered or with edges is somehow dark and doesnt really fit in the liquidglass ribbon. change this

## Triage

No broken feature, no non-finite geometry, no missing body. The model is internally healthy, so the fault is in the interaction or the display — read `log.txt` around the timestamp above rather than `state.txt`.

## Shape of the model

- part: `Lesezeichen_Schmetterling 2`
- features: 4 (0 sick)
- sketches: 2
- work planes: 0

## Contents

- `part.json` — the document itself; load this to reproduce
- `sketches/` — 2 child sketch document(s)
- `state.txt` — every feature, its parameters, its solid or its error, every picked edge fingerprint, and every sketch with its full geometry and constraint list
- `log.txt` — this session (8281 lines); the report was written at the END of it
- `perf.txt` — frame and remesh timings
- `gestures.txt` — the RAW pointer stream leading into the report, before the gesture arena resolved it. Read this when the complaint is that a tap or drag did the wrong thing
- `reality.txt` — what Dart last handed the native renderer. The 3D body is drawn by RealityKit behind a platform view, so this is the last thing visible from this side of that boundary
- `screenshot.png` — what was on screen. NOTE: the 3D body is a platform view and is composited outside Flutter, so the shaded model is NOT in this image — the viewport area will look empty even when the body is present. Chrome, overlays and 2D sketches ARE captured. Use reality.txt and mesh.txt for the body.
- `env.txt` — build, device and backend versions
