# Bug report — 2026-09-06T14:29:17.614477

- **captured**: 2026-09-06T14:29:18.007049
- **build**: cb89839
- **os**: ios Version 27.0 (Build 24A5418b)
- **dart**: 3.13.2 (stable) (Tue Aug 25 01:01:12 2026 -0700) on "ios_arm64"
- **locale**: de_DE
- **qcad backend**: REAL — Prototype C-API 0.1.0 (Qt 6.7.3)
- **occt backend**: Prototype OCCT shim v29 (OCCT 7.9.3) (shim v29)
- **open part**: Lesezeichen_Schmetterling
- **parts loaded**: 1

## What the user saw

Es ruckelt sehr und die App ist sehr langsam und unbrauchbar. es soll auf soliden 60fps laufen auch bei diesem Modell und Gerät . panning und Orbit und Zoom sollen in jedem Fall smooth sein. im moment ist es unbrauchbar auf diesem iPad Air. nimm dir Zeit mach es so das Orbit Zoom und pan sowie anderes in jedem Fall smooth ist und nie so laggt.

## Triage

No broken feature, no non-finite geometry, no missing body. The model is internally healthy, so the fault is in the interaction or the display — read `log.txt` around the timestamp above rather than `state.txt`.

## Shape of the model

- part: `Lesezeichen_Schmetterling`
- features: 1 (0 sick)
- sketches: 3
- work planes: 0

## Contents

- `part.json` — the document itself; load this to reproduce
- `sketches/` — 3 child sketch document(s)
- `state.txt` — every feature, its parameters, its solid or its error, every picked edge fingerprint, and every sketch with its full geometry and constraint list
- `log.txt` — this session (12884 lines); the report was written at the END of it
- `perf.txt` — frame and remesh timings
- `gestures.txt` — the RAW pointer stream leading into the report, before the gesture arena resolved it. Read this when the complaint is that a tap or drag did the wrong thing
- `reality.txt` — what Dart last handed the native renderer. The 3D body is drawn by RealityKit behind a platform view, so this is the last thing visible from this side of that boundary
- `screenshot.png` — what was on screen.
- `env.txt` — build, device and backend versions
