# Bug report — 2026-09-08T16:04:37.954387

- **captured**: 2026-09-08T16:04:38.205629
- **build**: 1beede8
- **os**: ios Version 27.0 (Build 24A5430a)
- **dart**: 3.13.2 (stable) (Tue Aug 25 01:01:12 2026 -0700) on "ios_arm64"
- **locale**: de_CH
- **qcad backend**: REAL — Prototype C-API 0.1.0 (Qt 6.7.3)
- **occt backend**: Prototype OCCT shim v29 (OCCT 7.9.3) (shim v29)
- **open part**: Lampenbefestigung Marshydro
- **parts loaded**: 1

## What the user saw

i want to Anke a center plane between these 2 chanfers but it says the faces are not parallel. but they shouldn’t need to be parallel since it should just make a middle plane like it would with parallel faces

## Triage

No broken feature, no non-finite geometry, no missing body. The model is internally healthy, so the fault is in the interaction or the display — read `log.txt` around the timestamp above rather than `state.txt`.

## Shape of the model

- part: `Lampenbefestigung Marshydro`
- features: 4 (0 sick)
- sketches: 3
- work planes: 0

## Contents

- `part.json` — the document itself; load this to reproduce
- `sketches/` — 3 child sketch document(s)
- `state.txt` — every feature, its parameters, its solid or its error, every picked edge fingerprint, and every sketch with its full geometry and constraint list
- `log.txt` — this session (37796 lines); the report was written at the END of it
- `perf.txt` — frame and remesh timings
- `gestures.txt` — the RAW pointer stream leading into the report, before the gesture arena resolved it. Read this when the complaint is that a tap or drag did the wrong thing
- `reality.txt` — what Dart last handed the native renderer. The 3D body is drawn by RealityKit behind a platform view, so this is the last thing visible from this side of that boundary
- `screenshot.png` — what was on screen.
- `env.txt` — build, device and backend versions
