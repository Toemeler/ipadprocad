# Bug report — 2026-09-23T17:12:55.197549

- **captured**: 2026-09-23T17:12:55.398551
- **build**: ef66cf8
- **os**: windows "Windows 10 Home" 10.0 (Build 19045)
- **dart**: 3.13.4 (stable) (Tue Sep 15 01:01:15 2026 -0700) on "windows_x64"
- **locale**: en_GB
- **qcad backend**: REAL — Prototype C-API 0.1.0 (Qt 6.8.3)
- **occt backend**: Prototype OCCT shim v31 (OCCT 7.9.3) (shim v31)
- **display**: 1x — 1280 x 1400 logical, 1280 x 1400 physical
- **text scale**: 1.0
- **glass**: shader filter, program loaded
- **open part**: motorminimicro 2
- **parts loaded**: 1
- **assistant**: deepseek · deepseek-flash — available, edits=allowed, sessions=7
- **assistant tokens**: deepseek · deepseek-flash: 35 request(s), in=1117594 out=109128 reasoning=99609 cacheRead=878592 total=1226722

## What the user saw

das gehäuse ist viel grösser als es sein müsste und nicht an die form der innereien angepasst. ausserdem sehen die räder weird aus und nicht sinnvoll konstruiert. voralem die fasen. ausserdem ist der motor aufeinmal einfach verschwunden

## Triage

- SILENT Import1 (extrude): no solid and no error — the fold produced nothing and said nothing
- BODY GONE Solid1: every feature on it is without a solid

## Assistant

- 1 action block(s) were ROLLED BACK — see `ai/trace.txt` for which op failed and why
- 1 action block(s) FAILED PART-WAY and kept their first steps — see `ai/trace.txt` (cad.reverted, "kept")

## Shape of the model

- part: `motorminimicro 2`
- features: 9 (0 sick)
- sketches: 9
- work planes: 0

## Contents

- `part.json` — the document itself; load this to reproduce
- `sketches/` — 9 child sketch document(s)
- `state.txt` — every feature, its parameters, its solid or its error, every picked edge fingerprint, and every sketch with its full geometry and constraint list
- `log.txt` — this session (19094 lines); the report was written at the END of it
- `log_prev.txt` — the previous session
- `perf.txt` — frame and remesh timings
- `gestures.txt` — the RAW pointer stream leading into the report, before the gesture arena resolved it. Read this when the complaint is that a tap or drag did the wrong thing
- `reality.txt` — what Dart last handed the renderer. The shaded body is drawn by flutter_scene INSIDE Flutter here, so it is in `screenshot.png` too; this is the scene it was drawn from
- `screenshot.png` — what was on screen.
- `ai/diagnostics.json` — which provider and model were selected, whether the provider was actually available and by which route (on-device vs Private Cloud Compute for Apple Intelligence), whether the assistant was allowed to edit the part, and the token totals for the whole session. READ THIS FIRST for any report about the assistant
- `ai/transcript.txt` — the conversations about the open document in prose: what was asked, what was answered, and what the app reported back after running each block
- `ai/sessions.json` — EVERY stored conversation, every turn, including the `tool` turns that record what each action block did to the document. Attachment bytes are replaced by name/type/size. NOTE: this member and `ai/trace.txt` carry what was typed and what was answered, verbatim — no API key or credential is ever in either, but the conversations themselves are, so treat the bundle as you would the document it is about
- `ai/trace.txt` — the request-by-request flight recorder: the exact body sent to the provider, the reply it returned, token usage, the model's thinking or reasoning where the provider publishes it, the stop reason, every HTTP status with the provider's own error text, and every CAD op the assistant ran with its timing. This is the file that answers "why did it say that"
- `ai/trace.json` — the same events as structured data
- `env.txt` — build, device and backend versions
