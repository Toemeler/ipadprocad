# Bug report — 2026-09-09T23:06:35.866184

- **captured**: 2026-09-09T23:06:36.041753
- **build**: 826413b
- **os**: ios Version 27.0 (Build 24A5408d)
- **dart**: 3.13.2 (stable) (Tue Aug 25 01:01:12 2026 -0700) on "ios_arm64"
- **locale**: de_CH
- **qcad backend**: REAL — Prototype C-API 0.1.0 (Qt 6.7.3)
- **occt backend**: Prototype OCCT shim v29 (OCCT 7.9.3) (shim v29)
- **display**: 3x — 390 x 844 logical, 1170 x 2532 physical
- **text scale**: 1.0
- **glass**: shader filter, program loaded
- **open part**: (none)
- **parts loaded**: 1

## What the user saw

the sync clearly doesnt work, i just Synced Bit still have an old version

## Triage

- no part is open

## Contents

- `log.txt` — this session (8462 lines); the report was written at the END of it
- `perf.txt` — frame and remesh timings
- `gestures.txt` — the RAW pointer stream leading into the report, before the gesture arena resolved it. Read this when the complaint is that a tap or drag did the wrong thing
- `reality.txt` — what Dart last handed the native renderer. The 3D body is drawn by RealityKit behind a platform view, so this is the last thing visible from this side of that boundary
- `screenshot.png` — what was on screen.
- `env.txt` — build, device and backend versions
