# Bug report — 2026-09-11T11:49:36.356419

- **captured**: 2026-09-11T11:49:36.582442
- **build**: 8c7a3a1
- **os**: ios Version 27.0 (Build 24A5430a)
- **dart**: 3.13.3 (stable) (Tue Sep 1 01:07:17 2026 -0700) on "ios_arm64"
- **locale**: de_CH
- **qcad backend**: REAL — Prototype C-API 0.1.0 (Qt 6.7.3)
- **occt backend**: Prototype OCCT shim v29 (OCCT 7.9.3) (shim v29)
- **display**: 2x — 1600 x 1200 logical, 3200 x 2400 physical
- **text scale**: 1.0
- **glass**: shader filter, program loaded
- **open part**: Part2
- **parts loaded**: 1

## What the user saw

somehow the planes look weird. the edges are the same color and exactly the same even when they are behind another plane. this looks very weird

## Triage

No broken feature, no non-finite geometry, no missing body. The model is internally healthy, so the fault is in the interaction or the display — read `log.txt` around the timestamp above rather than `state.txt`.

## Shape of the model

- part: `Part2`
- features: 0 (0 sick)
- sketches: 0
- work planes: 0

## Contents

- `part.json` — the document itself; load this to reproduce
- `state.txt` — every feature, its parameters, its solid or its error, every picked edge fingerprint, and every sketch with its full geometry and constraint list
- `log.txt` — this session (23535 lines); the report was written at the END of it
- `perf.txt` — frame and remesh timings
- `gestures.txt` — the RAW pointer stream leading into the report, before the gesture arena resolved it. Read this when the complaint is that a tap or drag did the wrong thing
- `reality.txt` — what Dart last handed the native renderer. The 3D body is drawn by RealityKit behind a platform view, so this is the last thing visible from this side of that boundary
- `screenshot.png` — what was on screen.
- `env.txt` — build, device and backend versions
