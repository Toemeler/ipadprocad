# Bug report — 2026-09-16T22:56:44.448416

- **captured**: 2026-09-16T22:56:44.630388
- **build**: cf0ce5c
- **os**: ios Version 27.0 (Build 24A5408d)
- **dart**: 3.13.3 (stable) (Tue Sep 1 01:07:17 2026 -0700) on "ios_arm64"
- **locale**: de_CH
- **qcad backend**: REAL — Prototype C-API 0.1.0 (Qt 6.7.3)
- **occt backend**: Prototype OCCT shim v30 (OCCT 7.9.3) (shim v30)
- **display**: 3x — 390 x 844 logical, 1170 x 2532 physical
- **text scale**: 1.0
- **glass**: shader filter, program loaded
- **open part**: Lampenbefestigung Marshydro
- **parts loaded**: 1

## What the user saw

plane outlines should in every case be just one pixel in thcikness. their highlight corner points a few more but Not much

## Triage

No broken feature, no non-finite geometry, no missing body. The model is internally healthy, so the fault is in the interaction or the display — read `log.txt` around the timestamp above rather than `state.txt`.

## Shape of the model

- part: `Lampenbefestigung Marshydro`
- features: 4 (0 sick)
- sketches: 4
- work planes: 1

## Contents

- `part.json` — the document itself; load this to reproduce
- `sketches/` — 4 child sketch document(s)
- `state.txt` — every feature, its parameters, its solid or its error, every picked edge fingerprint, and every sketch with its full geometry and constraint list
- `log.txt` — this session (24315 lines); the report was written at the END of it
- `perf.txt` — frame and remesh timings
- `gestures.txt` — the RAW pointer stream leading into the report, before the gesture arena resolved it. Read this when the complaint is that a tap or drag did the wrong thing
- `reality.txt` — what Dart last handed the native renderer. The 3D body is drawn by RealityKit behind a platform view, so this is the last thing visible from this side of that boundary
- `screenshot.png` — what was on screen.
- `env.txt` — build, device and backend versions
