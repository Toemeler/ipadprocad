# Bug report — 2026-09-23T10:20:45.535024

- **captured**: 2026-09-23T10:20:45.834571
- **build**: c271cd9
- **os**: ios Version 27.0 (Build 24A5430a)
- **dart**: 3.13.4 (stable) (Tue Sep 15 01:01:15 2026 -0700) on "ios_arm64"
- **locale**: de_CH
- **qcad backend**: REAL — Prototype C-API 0.1.0 (Qt 6.7.3)
- **occt backend**: Prototype OCCT shim v31 (OCCT 7.9.3) (shim v31)
- **display**: 2x — 1600 x 1200 logical, 3200 x 2400 physical
- **text scale**: 1.0
- **glass**: shader filter, program loaded
- **open part**: Part4
- **parts loaded**: 1
- **assistant**: deepseek · deepseek-flash — available, edits=allowed, sessions=26
- **assistant tokens**: deepseek · deepseek-flash: 11 request(s), in=205724 out=39775 reasoning=37425 cacheRead=169600 total=245499

## What the user saw

there were errors and it is not fdm printable or a good design

## Triage

No broken feature, no non-finite geometry, no missing body. The model is internally healthy, so the fault is in the interaction or the display — read `log.txt` around the timestamp above rather than `state.txt`.

## Assistant

- 3 action block(s) were ROLLED BACK — see `ai/trace.txt` for which op failed and why
- 2 action block(s) FAILED PART-WAY and kept their first steps — see `ai/trace.txt` (cad.reverted, "kept")

## Shape of the model

- part: `Part4`
- features: 4 (0 sick)
- sketches: 4
- work planes: 0

## Contents

- `part.json` — the document itself; load this to reproduce
- `sketches/` — 4 child sketch document(s)
- `state.txt` — every feature, its parameters, its solid or its error, every picked edge fingerprint, and every sketch with its full geometry and constraint list
- `log.txt` — this session (22142 lines); the report was written at the END of it
- `perf.txt` — frame and remesh timings
- `gestures.txt` — the RAW pointer stream leading into the report, before the gesture arena resolved it. Read this when the complaint is that a tap or drag did the wrong thing
- `reality.txt` — what Dart last handed the native renderer. The 3D body is drawn by RealityKit behind a platform view, so this is the last thing visible from this side of that boundary
- `screenshot.png` — what was on screen.
- `ai/diagnostics.json` — which provider and model were selected, whether the provider was actually available and by which route (on-device vs Private Cloud Compute for Apple Intelligence), whether the assistant was allowed to edit the part, and the token totals for the whole session. READ THIS FIRST for any report about the assistant
- `ai/transcript.txt` — the conversations about the open document in prose: what was asked, what was answered, and what the app reported back after running each block
- `ai/sessions.json` — EVERY stored conversation, every turn, including the `tool` turns that record what each action block did to the document. Attachment bytes are replaced by name/type/size. NOTE: this member and `ai/trace.txt` carry what was typed and what was answered, verbatim — no API key or credential is ever in either, but the conversations themselves are, so treat the bundle as you would the document it is about
- `ai/trace.txt` — the request-by-request flight recorder: the exact body sent to the provider, the reply it returned, token usage, the model's thinking or reasoning where the provider publishes it, the stop reason, every HTTP status with the provider's own error text, and every CAD op the assistant ran with its timing. This is the file that answers "why did it say that"
- `ai/trace.json` — the same events as structured data
- `env.txt` — build, device and backend versions
