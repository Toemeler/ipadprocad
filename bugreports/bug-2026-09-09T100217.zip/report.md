# Bug report — 2026-09-09T10:02:17.240289

- **captured**: 2026-09-09T10:02:17.311335
- **build**: fe68618
- **os**: windows "Windows 10 Home" 10.0 (Build 19045)
- **dart**: 3.13.2 (stable) (Tue Aug 25 01:01:12 2026 -0700) on "windows_x64"
- **locale**: en_GB
- **qcad backend**: REAL — Prototype C-API 0.1.0 (Qt 6.8.3)
- **occt backend**: Prototype OCCT shim v29 (OCCT 7.9.3) (shim v29)
- **display**: 1.25x — 1536 x 824 logical, 1920 x 1030 physical
- **text scale**: 1.0
- **glass**: shader filter, program loaded
- **open part**: Lampenbefestigung Marshydro
- **parts loaded**: 1

## What the user saw

why is the workplane green on windows, and it seems it is way bigger than the stuff that is there

## Triage

No broken feature, no non-finite geometry, no missing body. The model is internally healthy, so the fault is in the interaction or the display — read `log.txt` around the timestamp above rather than `state.txt`.

## Shape of the model

- part: `Lampenbefestigung Marshydro`
- features: 4 (0 sick)
- sketches: 4
- work planes: 1

## Contents

- `part.json` — the document itself; load this to reproduce
- `sketches/` — 4 child sketch document(s)
- `state.txt` — every feature, its parameters, its solid or its error, every picked edge fingerprint, and every sketch with its full geometry and constraint list
- `log.txt` — this session (49114 lines); the report was written at the END of it
- `perf.txt` — frame and remesh timings
- `gestures.txt` — the RAW pointer stream leading into the report, before the gesture arena resolved it. Read this when the complaint is that a tap or drag did the wrong thing
- `reality.txt` — what Dart last handed the native renderer. The 3D body is drawn by RealityKit behind a platform view, so this is the last thing visible from this side of that boundary
- `screenshot.png` — what was on screen.
- `env.txt` — build, device and backend versions
