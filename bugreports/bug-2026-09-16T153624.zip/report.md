# Bug report — 2026-09-16T15:36:24.668336

- **captured**: 2026-09-16T15:36:24.713913
- **build**: 4245449
- **os**: windows "Windows 10 Home" 10.0 (Build 19045)
- **dart**: 3.13.3 (stable) (Tue Sep 1 01:07:17 2026 -0700) on "windows_x64"
- **locale**: en_GB
- **qcad backend**: REAL — Prototype C-API 0.1.0 (Qt 6.8.3)
- **occt backend**: Prototype OCCT shim v29 (OCCT 7.9.3) (shim v29)
- **display**: 1x — 1376 x 1032 logical, 1376 x 1032 physical
- **text scale**: 1.0
- **glass**: shader filter, program loaded
- **open part**: Sketch1
- **parts loaded**: 0

## What the user saw

i cant offset this circle with the line in one offset somehow it seems not connected. also i cant see the dimension on the small circle even though it clearly should have a dimension

## Triage

- no part is open

## Contents

- `log.txt` — this session (113 lines); the report was written at the END of it
- `log_prev.txt` — the previous session
- `perf.txt` — frame and remesh timings
- `gestures.txt` — the RAW pointer stream leading into the report, before the gesture arena resolved it. Read this when the complaint is that a tap or drag did the wrong thing
- `reality.txt` — what Dart last handed the renderer. The shaded body is drawn by flutter_scene INSIDE Flutter here, so it is in `screenshot.png` too; this is the scene it was drawn from
- `screenshot.png` — what was on screen.
- `env.txt` — build, device and backend versions
