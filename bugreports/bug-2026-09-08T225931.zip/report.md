# Bug report — 2026-09-08T22:59:31.709568

- **captured**: 2026-09-08T22:59:31.880679
- **build**: 5dd0ff7
- **os**: windows "Windows 10 Home" 10.0 (Build 19045)
- **dart**: 3.13.2 (stable) (Tue Aug 25 01:01:12 2026 -0700) on "windows_x64"
- **locale**: en_GB
- **qcad backend**: REAL — Prototype C-API 0.1.0 (Qt 6.8.3)
- **occt backend**: Prototype OCCT shim v29 (OCCT 7.9.3) (shim v29)
- **open part**: Lampenbefestigung Marshydro
- **parts loaded**: 1

## What the user saw

the plane which was made somehow does not appear in the modell browser. idk why. also only tested on windows

## Triage

No broken feature, no non-finite geometry, no missing body. The model is internally healthy, so the fault is in the interaction or the display — read `log.txt` around the timestamp above rather than `state.txt`.

## Shape of the model

- part: `Lampenbefestigung Marshydro`
- features: 4 (0 sick)
- sketches: 3
- work planes: 1

## Contents

- `part.json` — the document itself; load this to reproduce
- `sketches/` — 3 child sketch document(s)
- `state.txt` — every feature, its parameters, its solid or its error, every picked edge fingerprint, and every sketch with its full geometry and constraint list
- `log.txt` — this session (30073 lines); the report was written at the END of it
- `perf.txt` — frame and remesh timings
- `gestures.txt` — the RAW pointer stream leading into the report, before the gesture arena resolved it. Read this when the complaint is that a tap or drag did the wrong thing
- `reality.txt` — what Dart last handed the native renderer. The 3D body is drawn by RealityKit behind a platform view, so this is the last thing visible from this side of that boundary
- `screenshot.png` — what was on screen.
- `env.txt` — build, device and backend versions
