# Bug report — 2026-09-21T21:48:31.787558

- **captured**: 2026-09-21T21:48:32.044746
- **build**: 232e343
- **os**: ios Version 27.0 (Build 24A5430a)
- **dart**: 3.13.4 (stable) (Tue Sep 15 01:01:15 2026 -0700) on "ios_arm64"
- **locale**: de_CH
- **qcad backend**: REAL — Prototype C-API 0.1.0 (Qt 6.7.3)
- **occt backend**: Prototype OCCT shim v30 (OCCT 7.9.3) (shim v30)
- **display**: 2x — 1600 x 1200 logical, 3200 x 2400 physical
- **text scale**: 1.0
- **glass**: shader filter, program loaded
- **open part**: Part11
- **parts loaded**: 1
- **assistant**: deepseek · deepseek-flash — available, edits=allowed, sessions=15
- **assistant tokens**: deepseek · deepseek-flash: 17 request(s), in=143909 out=43134 reasoning=41343 cacheRead=106752 total=187043

## What the user saw

there were a lot of issues. it did the Modell pretty good but then decided that it isnt good even when it was and made it less good by making one edge without a fillet somehow. also then i got an error. then it made a handle which looks like circles but isnt really and tried to add fillets to it which failed and looked like shit. Fix all the ai related issues but also the bugs that are just app bugs not ai related

## Triage

No broken feature, no non-finite geometry, no missing body. The model is internally healthy, so the fault is in the interaction or the display — read `log.txt` around the timestamp above rather than `state.txt`.

## Assistant

- LAST TURN FAILED: cancelled in session "make a designer cup which is fully production ready an"
- LAST ASSISTANT FAULT: cancelled — ClientException: ClientException: Connection closed while receiving data, uri=https://api.deepseek.com/chat/completions
- 5 action block(s) were ROLLED BACK — see `ai/trace.txt` for which op failed and why

## Shape of the model

- part: `Part11`
- features: 5 (0 sick)
- sketches: 3
- work planes: 0

## Contents

- `part.json` — the document itself; load this to reproduce
- `sketches/` — 3 child sketch document(s)
- `state.txt` — every feature, its parameters, its solid or its error, every picked edge fingerprint, and every sketch with its full geometry and constraint list
- `log.txt` — this session (23420 lines); the report was written at the END of it
- `perf.txt` — frame and remesh timings
- `gestures.txt` — the RAW pointer stream leading into the report, before the gesture arena resolved it. Read this when the complaint is that a tap or drag did the wrong thing
- `reality.txt` — what Dart last handed the native renderer. The 3D body is drawn by RealityKit behind a platform view, so this is the last thing visible from this side of that boundary
- `screenshot.png` — what was on screen.
- `ai/diagnostics.json` — which provider and model were selected, whether the provider was actually available and by which route (on-device vs Private Cloud Compute for Apple Intelligence), whether the assistant was allowed to edit the part, and the token totals for the whole session. READ THIS FIRST for any report about the assistant
- `ai/transcript.txt` — the conversations about the open document in prose: what was asked, what was answered, and what the app reported back after running each block
- `ai/sessions.json` — EVERY stored conversation, every turn, including the `tool` turns that record what each action block did to the document. Attachment bytes are replaced by name/type/size. NOTE: this member and `ai/trace.txt` carry what was typed and what was answered, verbatim — no API key or credential is ever in either, but the conversations themselves are, so treat the bundle as you would the document it is about
- `ai/trace.txt` — the request-by-request flight recorder: the exact body sent to the provider, the reply it returned, token usage, the model's thinking or reasoning where the provider publishes it, the stop reason, every HTTP status with the provider's own error text, and every CAD op the assistant ran with its timing. This is the file that answers "why did it say that"
- `ai/trace.json` — the same events as structured data
- `env.txt` — build, device and backend versions
