# Bug report — 2026-09-10T14:24:21.039990

- **captured**: 2026-09-10T14:24:21.264663
- **build**: 0fa7246
- **os**: ios Version 27.0 (Build 24A5430a)
- **dart**: 3.13.3 (stable) (Tue Sep 1 01:07:17 2026 -0700) on "ios_arm64"
- **locale**: de_CH
- **qcad backend**: REAL — Prototype C-API 0.1.0 (Qt 6.7.3)
- **occt backend**: Prototype OCCT shim v29 (OCCT 7.9.3) (shim v29)
- **display**: 2x — 1600 x 1200 logical, 3200 x 2400 physical
- **text scale**: 1.0
- **glass**: shader filter, program loaded
- **open part**: (none)
- **parts loaded**: 0

## What the user saw

on iPhone and iPad i dont want the reload sync button. i just want to drag down in the menu and the loading wheel should come at the top. like in every other native iOS app. the button should only be there on desktop

## Triage

- no part is open

## Contents

- `log.txt` — this session (23519 lines); the report was written at the END of it
- `perf.txt` — frame and remesh timings
- `gestures.txt` — the RAW pointer stream leading into the report, before the gesture arena resolved it. Read this when the complaint is that a tap or drag did the wrong thing
- `reality.txt` — what Dart last handed the native renderer. The 3D body is drawn by RealityKit behind a platform view, so this is the last thing visible from this side of that boundary
- `screenshot.png` — what was on screen.
- `env.txt` — build, device and backend versions
