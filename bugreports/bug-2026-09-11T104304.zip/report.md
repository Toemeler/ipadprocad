# Bug report — 2026-09-11T10:43:04.499124

- **captured**: 2026-09-11T10:43:04.600362
- **build**: 8c7a3a1
- **os**: ios Version 27.0 (Build 24A5408d)
- **dart**: 3.13.3 (stable) (Tue Sep 1 01:07:17 2026 -0700) on "ios_arm64"
- **locale**: de_CH
- **qcad backend**: REAL — Prototype C-API 0.1.0 (Qt 6.7.3)
- **occt backend**: Prototype OCCT shim v29 (OCCT 7.9.3) (shim v29)
- **display**: 3x — 390 x 844 logical, 1170 x 2532 physical
- **text scale**: 1.0
- **glass**: shader filter, program loaded
- **open part**: Part1
- **parts loaded**: 1

## What the user saw

if the ribbon is retracted on ios there shouldbt be this Vertical bar. and it should only come expand when I swipe right from the left edge with a clean native Apple style animation

## Triage

No broken feature, no non-finite geometry, no missing body. The model is internally healthy, so the fault is in the interaction or the display — read `log.txt` around the timestamp above rather than `state.txt`.

## Shape of the model

- part: `Part1`
- features: 0 (0 sick)
- sketches: 0
- work planes: 0

## Contents

- `part.json` — the document itself; load this to reproduce
- `state.txt` — every feature, its parameters, its solid or its error, every picked edge fingerprint, and every sketch with its full geometry and constraint list
- `log.txt` — this session (15200 lines); the report was written at the END of it
- `perf.txt` — frame and remesh timings
- `gestures.txt` — the RAW pointer stream leading into the report, before the gesture arena resolved it. Read this when the complaint is that a tap or drag did the wrong thing
- `reality.txt` — what Dart last handed the native renderer. The 3D body is drawn by RealityKit behind a platform view, so this is the last thing visible from this side of that boundary
- `screenshot.png` — what was on screen.
- `env.txt` — build, device and backend versions
