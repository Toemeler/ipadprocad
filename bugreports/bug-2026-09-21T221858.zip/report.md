# Bug report — 2026-09-21T22:18:58.883562

- **captured**: 2026-09-21T22:18:59.072037
- **build**: 232e343
- **os**: ios Version 27.0 (Build 24A5430a)
- **dart**: 3.13.4 (stable) (Tue Sep 15 01:01:15 2026 -0700) on "ios_arm64"
- **locale**: de_CH
- **qcad backend**: REAL — Prototype C-API 0.1.0 (Qt 6.7.3)
- **occt backend**: Prototype OCCT shim v30 (OCCT 7.9.3) (shim v30)
- **display**: 2x — 1600 x 1200 logical, 3200 x 2400 physical
- **text scale**: 1.0
- **glass**: shader filter, program loaded
- **open part**: Part14
- **parts loaded**: 1
- **assistant**: deepseek · deepseek-flash — available, edits=allowed, sessions=19
- **assistant tokens**: no request was made in this session

## What the user saw

its not that bad but also really not good. I think it takes way to little time in the sketching phase where it should draw with all the diffrent sketch tools and look and change and redraw until it makes the extrusion/revolve or any other 3d tool. i think this is one of the reasons i get such low quality simple Modells. and also it should be more confident. it should not set such small and fast goals. i should try to make it perfect so take time on every step and think about every little thing like fillets or chamfers or screws or any manufacturing optimizations

## Triage

No broken feature, no non-finite geometry, no missing body. The model is internally healthy, so the fault is in the interaction or the display — read `log.txt` around the timestamp above rather than `state.txt`.

## Shape of the model

- part: `Part14`
- features: 3 (0 sick)
- sketches: 8
- work planes: 0

## Contents

- `part.json` — the document itself; load this to reproduce
- `sketches/` — 8 child sketch document(s)
- `state.txt` — every feature, its parameters, its solid or its error, every picked edge fingerprint, and every sketch with its full geometry and constraint list
- `log.txt` — this session (23354 lines); the report was written at the END of it
- `perf.txt` — frame and remesh timings
- `gestures.txt` — the RAW pointer stream leading into the report, before the gesture arena resolved it. Read this when the complaint is that a tap or drag did the wrong thing
- `reality.txt` — what Dart last handed the native renderer. The 3D body is drawn by RealityKit behind a platform view, so this is the last thing visible from this side of that boundary
- `screenshot.png` — what was on screen.
- `ai/diagnostics.json` — which provider and model were selected, whether the provider was actually available and by which route (on-device vs Private Cloud Compute for Apple Intelligence), whether the assistant was allowed to edit the part, and the token totals for the whole session. READ THIS FIRST for any report about the assistant
- `ai/transcript.txt` — the conversations about the open document in prose: what was asked, what was answered, and what the app reported back after running each block
- `ai/sessions.json` — EVERY stored conversation, every turn, including the `tool` turns that record what each action block did to the document. Attachment bytes are replaced by name/type/size. NOTE: this member and `ai/trace.txt` carry what was typed and what was answered, verbatim — no API key or credential is ever in either, but the conversations themselves are, so treat the bundle as you would the document it is about
- `ai/trace.txt` — the request-by-request flight recorder: the exact body sent to the provider, the reply it returned, token usage, the model's thinking or reasoning where the provider publishes it, the stop reason, every HTTP status with the provider's own error text, and every CAD op the assistant ran with its timing. This is the file that answers "why did it say that"
- `ai/trace.json` — the same events as structured data
- `env.txt` — build, device and backend versions
