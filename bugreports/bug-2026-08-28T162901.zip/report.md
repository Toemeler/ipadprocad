# Bug report — 2026-08-28T16:29:01.408778

- **captured**: 2026-08-28T16:29:01.570400
- **build**: 6889112
- **os**: ios Version 27.0 (Build 24A5390f)
- **dart**: 3.13.2 (stable) (Tue Aug 25 01:01:12 2026 -0700) on "ios_arm64"
- **locale**: de_CH
- **qcad backend**: REAL — Prototype C-API 0.1.0 (Qt 6.7.3)
- **occt backend**: Prototype OCCT shim v29 (OCCT 7.9.3) (shim v29)
- **open part**: (none)
- **parts loaded**: 1

## What the user saw

when im in the home tab with the cards, the individual items (bottom bar, bug button and other stuff) is still offset because of the ribbon if its on the left, bottom or. right. but in the menu everything should use the original position since the ribbon is not there. fix this.

## Triage

- no part is open

## Contents

- `log.txt` — this session (4855 lines); the report was written at the END of it
- `perf.txt` — frame and remesh timings
- `gestures.txt` — the RAW pointer stream leading into the report, before the gesture arena resolved it. Read this when the complaint is that a tap or drag did the wrong thing
- `reality.txt` — what Dart last handed the native renderer. The 3D body is drawn by RealityKit behind a platform view, so this is the last thing visible from this side of that boundary
- `screenshot.png` — what was on screen. NOTE: the 3D body is a platform view and is composited outside Flutter, so the shaded model is NOT in this image — the viewport area will look empty even when the body is present. Chrome, overlays and 2D sketches ARE captured. Use reality.txt and mesh.txt for the body.
- `env.txt` — build, device and backend versions
